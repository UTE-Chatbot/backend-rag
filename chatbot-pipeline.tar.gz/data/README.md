Structure of dataset is: title, content, category and subcategory
