1. Apply reflection model to have the ability to reflect on the current state of the system.
