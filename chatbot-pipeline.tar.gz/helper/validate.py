def is_nan_value(num):
    return num != num